import { NextResponse } from "next/server"
import { getNews } from "@/lib/api"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Math.min(Number.parseInt(searchParams.get("limit") || "10"), 50) // Max 50 items
    const offset = Number.parseInt(searchParams.get("offset") || "0")
    const includeComments = searchParams.get("includeComments") === "true"

    const news = await getNews(limit, offset, includeComments)
    return NextResponse.json(news)
  } catch (error) {
    console.error("Error fetching news:", error)
    return NextResponse.json({ error: "Failed to fetch news" }, { status: 500 })
  }
}
