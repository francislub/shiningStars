import mongoose from "mongoose";

const Student = mongoose.models.Student;

export default Student;