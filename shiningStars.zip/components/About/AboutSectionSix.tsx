'use client';
import { useState } from "react";
import Image from "next/image";

import image from "../../public/images/shin/stu.jpg";


const AboutSectionOne = () => {

  return (
    <section id="about" className="pt-16 md:pt-20 lg:pt-28">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-14 ">

        
        </div>
    </div>
    </section>
  )
};

export default AboutSectionOne;
