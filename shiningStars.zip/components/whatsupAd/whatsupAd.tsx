// pages/_app.js

import "/whatsupAd.css";

function Mywhatsup({ Component, pageProps }) {
  return <Component {...pageProps} />;
}

export default Mywhatsup;
